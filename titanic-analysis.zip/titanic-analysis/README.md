# Titanic Survival Data Analysis

This is a simple data analysis project using Python. It uses the Titanic dataset to explore the factors that influenced survival. The project demonstrates basic data cleaning, visualization, and statistical analysis using pandas, matplotlib, and seaborn.

## Dataset

The dataset used is the classic Titanic dataset from [Kaggle](https://www.kaggle.com/c/titanic/data) or from seaborn's built-in datasets.

## Installation

Clone this repo and install the requirements:

```bash
pip install -r requirements.txt
```

## Run the Notebook

Open the Jupyter notebook:

```bash
jupyter notebook titanic_analysis.ipynb
```

## Project Goals

- Understand the structure of the dataset
- Clean missing data
- Visualize the relationships between features
- Analyze survival rates based on features like gender, age, and class

## Libraries Used

- pandas
- matplotlib
- seaborn

## License

This project is open-source under the MIT license.
